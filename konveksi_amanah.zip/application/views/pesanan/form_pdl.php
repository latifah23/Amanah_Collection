<div class="container">
	<section class="content-header">
		<h1>
			Form Pesanan PDL
		</h1><br>
	</section>
	<section class="content">
		<form>

			<div class="row">

				<div class="col-md-12">

					<div class="form-group row">
						<label for="input" class="col-sm-3 col-form-label">Jenis Kain</label>
						<div class="col-sm-9">
							<select class="form-control " style="width: 100%;">
								<option>American Drill</option>
								<option>Nagata Drill</option>
								<option>Obor</option>
								<option>Taipan</option>
							</select>
						</div>
					</div>

					<div class="form-group row">
						<label for="input" class="col-sm-3 col-form-label">Warna Kain</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Warna Kain">
						</div>
					</div>

					<div class="form-group row">
						<label for="input" class="col-sm-3 col-form-label">Jumlah</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Jumlah">
						</div>
					</div>

				</div>
			</div>

			<div class="row">

				<div class="col-md-3">
					<div class="form-group row">
						<label for="input" class="col-sm-3 col-form-label"></label>
						<div class="col-sm-9">
						</div>
					</div>

				</div>
				<div class="col-md-3">
					<div class="form-group row">
						<label for="input" class="col-sm-3 col-form-label">XS</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Panjang">
							<input type="text" class="form-control" id="input" placeholder="Pendek"><br>
						</div>


						<label for="input" class="col-sm-3 col-form-label">L</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Panjang">
							<input type="text" class="form-control" id="input" placeholder="Pendek"><br>
						</div>

						<label for="input" class="col-sm-3 col-form-label">XXXL</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Panjang">
							<input type="text" class="form-control" id="input" placeholder="Pendek"><br>
						</div>


					</div>
				</div>

				<div class="col-md-3">
					<div class="form-group row">
						<label for="input" class="col-sm-3 col-form-label">S</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Panjang">
							<input type="text" class="form-control" id="input" placeholder="Pendek"><br>
						</div>


						<label for="input" class="col-sm-3 col-form-label">XL</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Panjang">
							<input type="text" class="form-control" id="input" placeholder="Pendek"><br>
						</div>

						<label for="input" class="col-sm-3 col-form-label">Jumbo</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Panjang">
							<input type="text" class="form-control" id="input" placeholder="Pendek"><br>
						</div>


					</div>
				</div>

				<div class="col-md-3">
					<div class="form-group row">
						<label for="input" class="col-sm-3 col-form-label">M</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Panjang">
							<input type="text" class="form-control" id="input" placeholder="Pendek"><br>
						</div>


						<label for="input" class="col-sm-3 col-form-label">XXL</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="input" placeholder="Panjang">
							<input type="text" class="form-control" id="input" placeholder="Pendek"><br>
						</div>


					</div>
				</div>
			</div>

			<div class="row">
				<div class="form-group">
					<label for="exampleInputFile" class="col-sm-3 col-form-label">Upload File</label>
					<div class="input-group">
						<div class="costum-file">
							<input type="file" class="custom-file-input" id="exampleInputFile">
							<label class="custom-file-label" for="exampleInputFile">Choose file</label>
						</div>
						<div class="input-group-append">
							<span class="input-group-text" id="">Upload</span>
						</div>
					</div>

				</div>

				<div class="form-group row">
					<label for="message" class="col-sm-3 col-form-label">Keterangan</label>
					<div class="col-sm-9">
						<textarea value="Keterangan" class="form-control">
              				</textarea>
					</div>
				</div>
			</div>
			<button type="button" class="btn btn-primary">SAVE</button>
			<button type="button" class="btn btn-danger">CANCEL</button>
		</form>
	</section>
</div>
