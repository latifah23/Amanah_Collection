ini riwayat
